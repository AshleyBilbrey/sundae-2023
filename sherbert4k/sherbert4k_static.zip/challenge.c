#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include <unistd.h>
#include "sherbert4k.h"
#include "s4k_disasm.h"

#define max(a, b)               \
	({                          \
		__typeof__(a) _a = (a); \
		__typeof__(b) _b = (b); \
		_a > _b ? _a : _b;      \
	})

#define min(a, b)               \
	({                          \
		__typeof__(a) _a = (a); \
		__typeof__(b) _b = (b); \
		_a < _b ? _a : _b;      \
	})

WINDOW* term;
uint16_t diskette[4096];
bool loaded_diskette = false;

void print_exit(const char* message)
{
	sleep(1);
	wprintw(term, message);
	wprintw(term, "\nPRESS ANY KEY TO SHUT DOWN\n");
	flushinp();
	wgetch(term);
	clear();
	refresh();
	endwin();
	exit(0);
}

void draw_debug_nav(char* goto_buff)
{
	mvwprintw(term, 0, 0, "Nav: PgUp PgDn Up Dn | Find: F, 0x%c%c%c, (G)o or (Q)uit | Quit: Q",
			  goto_buff[0] != 0 ? goto_buff[0] : '_',
			  goto_buff[1] != 0 ? goto_buff[1] : '_',
			  goto_buff[2] != 0 ? goto_buff[2] : '_');
	wrefresh(term);
}

void debugger_view()
{
	if (!loaded_diskette)
		return;
	
	char* disasm_buff = malloc(32 * sizeof(char) * 4096);
	disasm_buff[0] = '\0';

	s4k_disasm_img(diskette, disasm_buff);

	int lines = 1;
	char* c = disasm_buff;
	while (*c != '\0') { if (*c == '\n') lines++; c++; };

	int pad_row = 0;
	WINDOW* pad = newpad(lines + 1, 80);
	scrollok(pad, TRUE);

	mvwaddstr(pad, 0, 0, "ADD OPCODE\tOPND\tVALUE\n");
	waddstr(pad, disasm_buff);

	char goto_buff[4] = {0};
	int goto_buff_len = 0;
	draw_debug_nav(goto_buff);

	while (1)
	{
		prefresh(pad, pad_row, 0, 2, 1, 23, 80);
		
		int input = toupper(getch());
		if (input == KEY_DOWN)
			pad_row = min(pad_row + 1, lines);
		
		if (input == KEY_UP)
			pad_row = max(0, pad_row - 1);

		if (input == KEY_NPAGE)
			pad_row = min(pad_row + 23, lines);
		
		if (input == KEY_PPAGE)
			pad_row = max(pad_row - 23, 0);

		if (input == 'Q')
		{
			delwin(pad);
			free(disasm_buff);
			wrefresh(term);
			flushinp();
			return;
		}

		if (input == 'F')
		{
			goto_buff_len = 0;
			input = toupper(getch());
			while (input != 'G' && input != 'Q')
			{
				if (input == KEY_BACKSPACE)
				{
					goto_buff_len = max(0, goto_buff_len - 1);
					memset(goto_buff + goto_buff_len, 0, 3 - goto_buff_len);
					draw_debug_nav(goto_buff);
				}

				if (isxdigit(input) && goto_buff_len != 3)
				{
					goto_buff[goto_buff_len++] = toupper(input);
					goto_buff[goto_buff_len] = '\0';
					draw_debug_nav(goto_buff);
				}

				input = toupper(getch());
			}

			if (input == 'G')
				sscanf(goto_buff, "%x", &pad_row);

			memset(goto_buff, 0, 4);

			draw_debug_nav(goto_buff);
		}
	}
}


int main(int argc, char** argv)
{
	if (argc >= 2)
	{
		FILE *f = fopen(argv[1], "r");

		if (f != NULL && fread(diskette, sizeof(uint16_t), 4096, f) == 4096)
			loaded_diskette = true;

		fclose(f);
	}

	initscr();
	cbreak();
	noecho();
	keypad(stdscr, TRUE);
	resizeterm(26, 82);
	box(stdscr, 0, 0);
	curs_set(0);
	refresh();

	term = newwin(24, 80, 1, 1);
	scrollok(term, TRUE);
	sleep(1);

	mvwaddstr(term, 10, 40 - strlen("*** SHERBERT 4K WORD COMPUTER***") / 2, "*** SHERBERT 4K WORD COMPUTER***");
	mvwaddstr(term, 11, 40 - strlen("DESIGNED BY ORANGE JUICE SYSTEMS") / 2, "DESIGNED BY ORANGE JUICE SYSTEMS");
	
	if (argc >= 2)
		mvwaddstr(term, 23, 40 - strlen("[D] PROGRAM DISASSEMBLY") / 2, "[D] PROGRAM DISASSEMBLY");

	wrefresh(term);

	sleep(1);

	wmove(term, 14, 40 - 2);

	for (int i = 0; i < 4; i++)
	{
		
		nodelay(term, TRUE);
		wtimeout(term, 700);
		int c = wgetch(term);
		
		if (c == 'd' || c == 'D')
		{
			wclear(term);
			wrefresh(term);
			debugger_view();
		}

		waddch(term, '.');
		wrefresh(term);
	}

	wclear(term);
	wrefresh(term);

	if (argc < 2)
		print_exit("NO DISKETTE LOADED");

	wprintw(term, "LOADING DISKETTE DATA...\n");
	wmove(term, 0, 0);

	if (!loaded_diskette)
		print_exit("INVALID DISKETTE LOCATION");

	s4k_load_image(diskette);
	wrefresh(term);
	sleep(1);
	wclear(term);
	wrefresh(term);
	flushinp();
	curs_set(2);

	while (1)
	{
		char buff[16];
		buff[0] = '\0';
		s4k_disasm(s4k.state.mem[s4k.state.pc], buff);
		//wprintw(term, "INSTR: %s\n", buff);
		s4k_run();

		if (s4k.state.run_state == S4K_HALTED)
			print_exit("[!] PROGRAM HALTED");

		if (s4k.state.io_state == IO_READ_READY)
		{
			int x, y;
			getyx(term, x, y);

			char c = s4k.state.io_buff & 0xFF;

			if (c == 0x12) wmove(term, x, y - 1);
			else if (c == 0x13) wmove(term, x, y + 1);
			else if (c == 0x14) wmove(term, x + 1, 0);
			else waddch(term, c);

			s4k.state.io_state = IO_IDLE;
		}

		if (s4k.state.io_state == IO_WRITE_REQUESTED)
		{
			flushinp();
			
			int input = getch();
			s4k.state.io_buff = (uint16_t)input;
			s4k.state.io_state = IO_WRITE_READY;
		}

		//wprintw(term, "PC: %d | AC: %d\n", s4k.state.pc, s4k.state.acc);

		wrefresh(term);
	}

	endwin();
}