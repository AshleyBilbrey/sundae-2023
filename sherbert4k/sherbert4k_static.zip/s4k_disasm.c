#include "s4k_disasm.h"

#define BIT_SET(w, b) (w >> (b - 1) & 1)

#define OPCODE(instr) ((instr >> 13) & 0b111)
#define OPERAND(instr) (instr & 0xFFF)
#define INDIRECT(instr) BIT_SET(instr, 13)
#define GROUP1(instr) OPCODE(instr) == 0b111 && !BIT_SET(instr, 13)
#define GROUP2OR(instr) OPCODE(instr) == 0b111 && BIT_SET(instr, 13) \
    && !BIT_SET(instr, 4) && !BIT_SET(instr, 1)
#define GROUP2AND(instr) OPCODE(instr) == 0b111 && BIT_SET(instr, 13) \
    && BIT_SET(instr, 4) && !BIT_SET(instr, 1)

const char* opcode_table[8] = {"AND", "TAD", "ISZ", "DCA", "JMS", "JMP", "IOT", "OPR"};
const char* group1[8] = {"CLA", "CLL", "CMA", "CML", "RAR", "RAL", "BSW", "IAC"};
const char* group2or[4] = {"CLA", "SMA", "SZA", "SNL"};
const char* group2and[4] = {"CLA", "SPA", "SNA", "SZL"};

void s4k_disasm(uint16_t instr, char* out)
{
    char hex[5];
    if (OPCODE(instr) < 0b110)
    {
        strncat(out, opcode_table[OPCODE(instr)], 3);
        
        if (INDIRECT(instr))
            strcat(out, " I");
        else
            strcat(out, "  ");

        strcat(out, "\t");

        snprintf(hex, 5, "%04X", OPERAND(instr));
        strncat(out, hex, 4);
    }
    else if (OPCODE(instr) == 0b110 && BIT_SET(instr, 1))
    {
        strcat(out, "IOR ");
    }
    else if (OPCODE(instr) == 0b110 && !BIT_SET(instr, 1))
    {
        strcat(out, "IOW ");
    }
    else if (instr == 0xF001)
    {
        strcat(out, "HALT ");
    }
    else if (GROUP1(instr))
    {
        for (int i = 0; i < 8; i++)
        {
            if (BIT_SET(instr, 8 - i))
            {
                strncat(out, group1[i], 3);
                strcat(out, " ");
            }
        }
    }
    else if (GROUP2OR(instr))
    {
        for (int i = 0; i < 4; i++)
        {
            if (BIT_SET(instr, 8 - i))
            {
                strncat(out, group2or[i], 3);
                strcat(out, " ");
            }
        }
    }
    else if (GROUP2AND(instr))
    {
        for (int i = 0; i < 4; i++)
        {
            if (BIT_SET(instr, 8 - i))
            {
                strncat(out, group2and[i], 3);
                strcat(out, " ");
            }
        }
    }
    else
    {
        strcat(out, "UKWN");
    }

    if (OPCODE(instr) >= 0b110)
        strcat(out, "\t");


    strcat(out, "\t0x");
    snprintf(hex, 5, "%04X", instr);
    strncat(out, hex, 4);
}

void s4k_disasm_img(uint16_t* img, char* out)
{
    for (int i = 0; i < 4096; i++)
    {
        char addr[4];
        snprintf(addr, 4, "%03X", i);
        strncat(out, addr, 3);
        strcat(out, " ");
        s4k_disasm(img[i], out);
        strcat(out, "\n");
    }
}