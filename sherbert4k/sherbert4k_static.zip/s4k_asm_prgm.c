#include "s4k_asm.h"
#include <stdlib.h>
#include <sys/stat.h>

int main(int argc, char** argv)
{
    if (argc != 3)
    {
        printf("Usage: asm s4k_asm.s output_image\n");
        return 2;
    }

    FILE *in_file = fopen(argv[1], "r");

    if (in_file == NULL)
    {
        printf("Error: failed to open file %s\n", argv[1]);
        return 1;
    }

    struct stat stat;
    fstat(fileno(in_file), &stat);

    char* asm_src = malloc(stat.st_size + 1);

    fread(asm_src, stat.st_size, 1, in_file);
    fclose(in_file);

    uint16_t image[4096];
    memset(image, 0, 4096 * sizeof(uint16_t));

    int err_line;
    if (!s4k_assemble(asm_src, image, &err_line))
    {
        printf("Error: failed to assemble. Error at line %u\n", err_line);
        return 1;
    }

    free(asm_src);

    FILE *out_file = fopen(argv[2], "w");

    if (out_file == NULL)
    {
        printf("Error: failed to open file %s\n", argv[2]);
        return 1;
    }

    fwrite(image, sizeof(uint16_t), 4096, out_file);
    fclose(out_file);

    return 0;
}