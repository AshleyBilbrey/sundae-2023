#pragma once
#include <string.h>
#include <stdbool.h>
#include <inttypes.h>

typedef enum { IO_IDLE, IO_READ_READY, IO_WRITE_REQUESTED, IO_WRITE_READY } s4k_io_state;
typedef enum { S4K_HALTED, S4K_RUNNING, S4K_READY } s4k_run_state;

typedef struct
{
    int16_t mem[0x1000];
    bool link;
    int16_t acc;
    uint16_t pc;

    s4k_run_state run_state;
    s4k_io_state io_state;
    uint16_t io_buff;
} s4k_state;

typedef struct
{
    s4k_state state;
    bool interrupted;
} s4k_emu;

extern s4k_emu s4k;

void s4k_load_image(uint16_t *from);
void s4k_run();
