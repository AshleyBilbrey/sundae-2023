#include "s4k_disasm.h"

int main(int argc, char** argv)
{
    if (argc != 2)
    {
        printf("Usage: disasm image\n");
        return 2;
    }

    FILE* f = fopen(argv[1], "r");

    if (f == NULL)
    {
        printf("Error: failed to open file\n");
        return 1;
    }

    uint16_t image[4096];

    if (fread(image, sizeof(uint16_t), 4096, f) != 4096)
    {
        printf("Error: corrupted image\n");
        return 1;
    }

    fclose(f);

    char buffer[16 * 4096];
    buffer[0] = '\0';

    s4k_disasm_img(image, buffer);

    printf(buffer);
    return 0;
}