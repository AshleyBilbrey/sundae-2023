#pragma once
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <inttypes.h>

typedef struct
{
    char* name;
    unsigned addr;
} label;

bool s4k_assemble(const char *src, uint16_t *out, int *err_line);