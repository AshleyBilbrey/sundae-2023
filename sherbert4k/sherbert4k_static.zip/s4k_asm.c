#include "s4k_asm.h"

#define WS " \t"
#define OPCODE(o) (uint16_t)(o << 13)
#define BIT(n) (uint16_t)(1 << (n - 1))
#define INDIRECT BIT(13)

typedef enum {NONE, MICRO_GROUP1, MICRO_GROUP2OR, MICRO_GROUP2AND} micro_op;

char* opcode_mnemonic[6] = {"AND", "TAD", "ISZ", "DCA", "JMS", "JMP"};
char* micro_group1[8] = {"CLA", "CLL", "CMA", "CML", "RAR", "RAL", "BSW", "IAC"};
char* micro_group2or[4] = {"CLA", "SMA", "SZA", "SNL"};
char* micro_group2and[4] = {"CLA", "SPA", "SNA", "SZL"};

int get_micro_op_idx(char* tok, micro_op type)
{
    if (type == MICRO_GROUP1)
    {
        for (unsigned i = 0; i < sizeof(micro_group1) / sizeof(*micro_group1); i++)
        {
            if (strcasecmp(tok, micro_group1[i]) == 0)
                return i;
        }
    }

    if (type == MICRO_GROUP2OR)
    {
        for (unsigned i = 0; i < sizeof(micro_group2or) / sizeof(*micro_group2or); i++)
        {
            if (strcasecmp(tok, micro_group2or[i]) == 0)
                return i;
        }
    }

    if (type == MICRO_GROUP2AND)
    {
        for (unsigned i = 0; i < sizeof(micro_group2and) / sizeof(*micro_group2and); i++)
        {
            if (strcasecmp(tok, micro_group2and[i]) == 0)
                return i;
        }
    }

    return -1;
}

micro_op get_micro_op_type(char* tok)
{
    for (unsigned i = 0; i < sizeof(micro_group1) / sizeof(*micro_group1); i++)
    {
        if (strcasecmp(tok, micro_group1[i]) == 0)
            return MICRO_GROUP1;
    }

    for (unsigned i = 0; i < sizeof(micro_group2or) / sizeof(*micro_group2or); i++)
    {
        if (strcasecmp(tok, micro_group2or[i]) == 0)
            return MICRO_GROUP2OR;
    }

    for (unsigned i = 0; i < sizeof(micro_group2and) / sizeof(*micro_group2and); i++)
    {
        if (strcasecmp(tok, micro_group2and[i]) == 0)
            return MICRO_GROUP2AND;
    }

    return NONE;
}

bool s4k_assemble(const char* src, uint16_t* out, int* err_line)
{
    label labels[4096] = {0};
    int label_count = 0;
    bool pass1 = true;
    unsigned hex, addr, line_n;
    int micro_idx;

    char* src_cpy;
    char* str_saveptr;
    char* line_saveptr;

parse:
    addr = 0xF;
    line_n = 1;
    src_cpy = strdup(src);

    for (char* line = strtok_r(src_cpy, "\n", &str_saveptr);
        line != NULL;
        line = strtok_r(NULL, "\n", &str_saveptr), line_n++)
    {
        char *tok1 = strtok_r(line, WS, &line_saveptr);

        if (tok1 == NULL)
            continue;
        
        int tok1_l = strlen(tok1);
        char *tok2 = strtok_r(NULL, WS, &line_saveptr);
        int tok2_l = tok2 == NULL ? 0 : strlen(tok2);

        if (tok1[0] == ';')
            continue;        
        
        if (strcasecmp(tok1, ".WORD") == 0)
        {
            if (tok2 == NULL || strtok_r(NULL, WS, &line_saveptr) != NULL)
                goto error;

            for (int i = 0; i < label_count; i++)
            {
                if (strcasecmp(tok2, labels[i].name) == 0)
                {
                    hex = labels[i].addr;
                    goto found_word_addr;
                }
            }

            if (!pass1)
                if (tok2_l > 4 || sscanf(tok2, "%x", &hex) != 1)
                    goto error;

found_word_addr:
            if (!pass1)
                out[addr] = hex;

            addr++;

            continue;
        }

        if (strcasecmp(tok1, ".ADDR") == 0)
        {
            if (tok2 == NULL || tok2_l > 3 
                || strtok_r(NULL, WS, &line_saveptr) != NULL
                || sscanf(tok2, "%x", &addr) != 1)
                goto error;
            
            continue;
        }

        if (strcasecmp(tok1, "IOR") == 0)
        {
            if (tok2 != NULL)
                goto error;

            if (!pass1)
                out[addr] = OPCODE(0b110) | 0b1;

            addr++;
            
            continue;
        }

        if (strcasecmp(tok1, "IOW") == 0)
        {
            if (tok2 != NULL)
                goto error;

            if (!pass1)
                out[addr] = OPCODE(0b110) | 0b0;

            addr++;
            continue;
        }

        if (strcasecmp(tok1, "HALT") == 0)
        {
            if (tok2 != NULL)
                goto error;

            if (!pass1)
                out[addr] = 0xF001;

            addr++;
            continue;
        }

        if (tok1[tok1_l - 1] == ':' && tok2 == NULL)
        {
            if (!pass1)
                continue;
            
            labels[label_count++] = 
                (label){ .name = strndup(tok1, tok1_l - 1), .addr = addr };
            
            continue;
        }

        bool continue_outer = false;
        for (unsigned i = 0; i < sizeof(opcode_mnemonic) / sizeof(*opcode_mnemonic); i++)
        {
            if (strcasecmp(tok1, opcode_mnemonic[i]) != 0)
                continue;

            if (pass1)
            {
                addr++;
                continue_outer = true;
                break;
            }
            
            out[addr] = OPCODE(i);

            if (tok2 == NULL)
                goto error;

            if (strcasecmp(tok2, "I") == 0)
            {
                out[addr] |= INDIRECT;
                tok2 = strtok_r(NULL, WS, &line_saveptr);

                if (tok2 == NULL)
                    goto error;
            }

            for (int i = 0; i < label_count; i++)
            {
                if (strcasecmp(tok2, labels[i].name) == 0)
                {
                    hex = labels[i].addr;
                    goto found_addr;
                }
            }

            if (strlen(tok2) > 4 || sscanf(tok2, "%x", &hex) != 1)
                goto error;

found_addr:
            out[addr] |= hex & 0xFFF;

            addr++;
            continue_outer = true;
            break;
        }

        if (continue_outer)
            continue;

        if (strcasecmp(tok1, "CLA") == 0)
        {
            if (pass1)
            {
                addr++;
                continue;
            }

            out[addr] = OPCODE(0b111) | BIT(8);

            if (tok2 == NULL)
            {
                addr++;
                continue;
            }

            tok1 = tok2;
            tok1_l = tok2_l;
            tok2 = strtok_r(NULL, WS, &line_saveptr);
        }

        micro_op micro_type = get_micro_op_type(tok1);

        if (micro_type != NONE)
        {
            if (pass1)
            {
                addr++;
                continue;
            }

            out[addr] |= OPCODE(0b111);

            if (micro_type == MICRO_GROUP2OR)
                out[addr] |= BIT(13);

            if (micro_type == MICRO_GROUP2AND)
                out[addr] |= BIT(13) | BIT(4);

            micro_idx = get_micro_op_idx(tok1, micro_type);

            if (micro_idx == -1)
                goto error;

            out[addr] |= BIT(8 - micro_idx);

            if (tok2 != NULL)
            {
                do
                {
                    micro_idx = get_micro_op_idx(tok2, micro_type);

                    if (micro_idx == -1)
                        goto error;

                    out[addr] |= BIT(8 - micro_idx);
                    tok2 = strtok_r(NULL, WS, &line_saveptr);
                } while (tok2 != NULL);
            }

            addr++;
        }
    }

    free(src_cpy);

    if (pass1)
    {
        pass1 = false;
        goto parse;
    }

    return true;

error:
    if (err_line != NULL)
        *err_line = line_n;

    free(src_cpy);

    return false;
}