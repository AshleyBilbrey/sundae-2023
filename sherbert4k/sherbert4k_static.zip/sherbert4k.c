#include "sherbert4k.h"

s4k_emu s4k;

#define BIT_SET(w, b) (w >> (b - 1) & 1)

#define AC s4k.state.acc
#define PC s4k.state.pc
#define LINK s4k.state.link
#define MEM s4k.state.mem
#define IO_STATE s4k.state.io_state
#define RUN_STATE s4k.state.run_state
#define IO_BUFF s4k.state.io_buff

#define INSTR ((uint16_t)MEM[PC])
#define ADDR (INSTR & 0xFFF)

#define INDIRECT BIT_SET(INSTR, 13)
#define OPRND_ADDR (INDIRECT ? (ADDR < 0x8 ? (uint16_t)(++MEM[ADDR]) : (uint16_t)MEM[ADDR]) : (ADDR))
#define OPCODE (INSTR >> 13)

#define GROUP1 !BIT_SET(INSTR, 13)

#define CLA BIT_SET(INSTR, 8)
#define CLL BIT_SET(INSTR, 7)
#define CMA BIT_SET(INSTR, 6)
#define CML BIT_SET(INSTR, 5)
#define RAR BIT_SET(INSTR, 4)
#define RAL BIT_SET(INSTR, 3)
#define IAC BIT_SET(INSTR, 1)

#define GROUP2OR BIT_SET(INSTR, 13) && !BIT_SET(INSTR, 4) && !BIT_SET(INSTR, 1)

#define SMA BIT_SET(INSTR, 7)
#define SZA BIT_SET(INSTR, 6)
#define SNL BIT_SET(INSTR, 5)

#define GROUP2AND BIT_SET(INSTR, 13) && BIT_SET(INSTR, 4) && !BIT_SET(INSTR, 1)

#define SPA BIT_SET(INSTR, 7)
#define SNA BIT_SET(INSTR, 6)
#define SZL BIT_SET(INSTR, 5)

#define CLA2 BIT_SET(INSTR, 8)

#define GROUP3HLT BIT_SET(INSTR, 13) && BIT_SET(INSTR, 1)

static void cla() { AC = 0; }
static void cll() { LINK = 0; }
static void cma() { AC = ~AC; }
static void cml() { LINK = !LINK; }
static void iac() { if (__builtin_add_overflow(AC, 1, &AC)) LINK = !LINK;}
static void rar() { bool old_link = LINK; LINK = BIT_SET(AC, 1); AC = (AC >> 1) | (old_link << 15); }
static void ral() { bool old_link = LINK; LINK = BIT_SET(AC, 16); AC = (AC << 1) | old_link; }

static void sma() { if (AC < 0) PC++; }
static void sza() { if (AC == 0) PC++; }
static void snl() { if (LINK) PC++; }

static void spa() { if (AC >= 0) PC++; }
static void sna() { if (AC != 0) PC++; }
static void szl() { if (!LINK) PC++; }

static void and() { AC &= MEM[OPRND_ADDR]; }
static void tad() { if (__builtin_add_overflow(AC, MEM[OPRND_ADDR], &AC)) LINK = !LINK; }
static void isz() { if (++MEM[OPRND_ADDR] == 0) PC++; }
static void dca() { MEM[OPRND_ADDR] = AC; AC = 0; }
static void jms() { MEM[OPRND_ADDR] = PC + 1; PC = OPRND_ADDR + 1; }
static void jmp() { PC = OPRND_ADDR; }
static void iot() {
    if (BIT_SET(INSTR, 1))
    {
        IO_STATE = IO_WRITE_REQUESTED;
    }
    else
    {
        IO_BUFF = AC;
        IO_STATE = IO_READ_READY;
    }
}
static void opr() {
    if (GROUP1)
    {
        if (CLA) cla();
        if (CLL) cll();
        if (CMA) cma();
        if (CML) cml();
        if (IAC) iac();
        if (RAR) rar();
        if (RAL) ral();
    }
    else if (GROUP2OR)
    {
        bool _sma = SMA, _sza = SZA,
             _snl = SNL, _cla2 = CLA2;
        if ( _sma) sma();
        if (_sza) sza();
        if (_snl) snl();
        if (_cla2) cla();
    }
    else if (GROUP2AND)
    {
        bool _spa = SPA, _sna = SNA,
            _szl = SZL, _cla2 = CLA2;
        if (_spa) spa();
        if (_sna) sna();
        if (_szl) szl();
        if (_cla2) cla();
    }
    else if (GROUP3HLT)
    {
        RUN_STATE = S4K_HALTED;
    }
}

void s4k_load_image(uint16_t* from)
{
    memcpy(MEM, from, 4096 * sizeof(uint16_t));
    PC = 8;
    RUN_STATE = S4K_READY;
}

void (*instr_table[8])() = {&and, &tad, &isz, &dca, &jms, &jmp, &iot, &opr};

void s4k_run()
{
    if (RUN_STATE == S4K_HALTED || IO_STATE == IO_READ_READY || IO_STATE == IO_WRITE_REQUESTED)
        return;

    if (IO_STATE == IO_WRITE_READY)
    {
        AC = IO_BUFF;
        IO_STATE = IO_IDLE;
    }

    RUN_STATE = S4K_RUNNING; 

    bool is_jmp = OPCODE == 0b100 || OPCODE == 0b101;
    
    instr_table[OPCODE]();

    if (!is_jmp)
        PC++;
}