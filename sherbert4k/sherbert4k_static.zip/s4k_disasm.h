#pragma once
#include <string.h>
#include <stdio.h>
#include <inttypes.h>

void s4k_disasm(uint16_t instr, char* out);
void s4k_disasm_img(uint16_t* img, char* out);